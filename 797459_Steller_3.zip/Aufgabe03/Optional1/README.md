MME2
====

repo for study purposes on MultiMedia Engineering 2
