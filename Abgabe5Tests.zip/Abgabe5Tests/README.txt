�bung 5 Tests
------------------------

Installation:
npm install
npm install jasmine-node -g

Bitte unbedingt in der spec/api_spec.js die base_url anpassen!

Ausf�hrung:
npm test